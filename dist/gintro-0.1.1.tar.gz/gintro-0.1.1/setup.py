from setuptools import setup, find_packages

setup(
    name='gintro',
    version='0.1.1',
    author='jfshen',
    packages=find_packages(),
    install_requires=[
        # 依赖列表
    ],
    # 其他元数据
)